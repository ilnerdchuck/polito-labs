#include "FreeRTOS.h"
#include "task.h"
#include "uart.h"
#include <queue.h>
#include <stdio.h>
#include <stdlib.h>

#define mainTASK_PRIORITY    ( tskIDLE_PRIORITY + 2 )

typedef struct order_s {
  int orderID;
  char itemDetails[50];
  int priority;
} order_t;

QueueHandle_t orderQueue;
QueueHandle_t shippingQueue;
QueueHandle_t messageQueue;

void inventoryPicker (void *pvParameters);
void packingStation (void *pvParameters);
void shippingController (void *pvParameters);
void loggerSystem (void *pvParameters);

int main(int argc, char **argv){

	(void) argc;
	(void) argv;

  UART_init();

  orderQueue = xQueueCreate(5, sizeof(order_t));
  shippingQueue = xQueueCreate(5, sizeof(order_t));
  messageQueue = xQueueCreate(20, sizeof(char)*51);

  if (orderQueue == NULL || shippingQueue == NULL || messageQueue == NULL) {
        UART_printf("Failed to create queues\n");
        return -1;
  }
	
  xTaskCreate(inventoryPicker, "Inventory Picker", 3000, NULL, mainTASK_PRIORITY+1, NULL); 
  xTaskCreate(packingStation, "Picking Station", 3000, NULL, mainTASK_PRIORITY+1, NULL); 
  xTaskCreate(shippingController, "Shipping Controller", 3000, NULL, mainTASK_PRIORITY+1, NULL); 
  xTaskCreate(loggerSystem, "Logger System", 3000, NULL, mainTASK_PRIORITY, NULL); 

	// Give control to the scheduler
	vTaskStartScheduler();

	// If everything ok should never reach here
  for( ; ; );
}

void inventoryPicker (void *pvParameters) {
  (void) pvParameters;

  order_t order;
  int i=0;
  char message[50];

  while (1) {
    UART_printf("Inventory\n");  
    order.orderID = i;
    sprintf(order.itemDetails, "Ordine numero: %d\n", order.orderID);
    order.priority = rand() % 3;
    sprintf(message, "Ordine numero %d preso\n", order.orderID);

    while(uxQueueSpacesAvailable(orderQueue)==0)
      vTaskDelay(200);

    xQueueSend(orderQueue, (void *) &order, portMAX_DELAY);
    while(uxQueueSpacesAvailable(messageQueue)==0)
      vTaskDelay(200);
    xQueueSend(messageQueue, (void *) message, portMAX_DELAY);
    
    vTaskDelay(rand() % 1000);
  }
}

void packingStation (void *pvParameters) {
  (void) pvParameters;

  order_t order;
  char message[50];
  
  while (1) {
    UART_printf("Packing\n");  
    while(xQueueReceive(orderQueue, (void *) &order, portMAX_DELAY)==pdFALSE)
      vTaskDelay(200);
    while(uxQueueSpacesAvailable(shippingQueue)==0)
      vTaskDelay(200);
    sprintf(message, "Ordine numero %d impacchettato\n", order.orderID);
    xQueueSend(shippingQueue, (void *) &order, portMAX_DELAY);
    while(uxQueueSpacesAvailable(messageQueue)==0)
      vTaskDelay(200);
    xQueueSend(messageQueue, (void *) message, portMAX_DELAY);

    vTaskDelay(rand() % 2000);
  }
}

void shippingController (void *pvParameters) {
  (void) pvParameters;
  order_t order;
  char message[50];
  while (1) {
    UART_printf("Shipping\n");  
    while(xQueueReceive(shippingQueue, (void *) &order, portMAX_DELAY)==pdFALSE)
      vTaskDelay(200);
    while(uxQueueSpacesAvailable(messageQueue)==0)
      vTaskDelay(200);
    sprintf(message, "Ordine numero %d spedito\n", order.orderID);
    xQueueSend(messageQueue, (void *) message, portMAX_DELAY);

    vTaskDelay(rand() % 5000);
  }

}

void loggerSystem (void *pvParameters) {
  (void) pvParameters;

  char message[50];
  
  while (1) {
    UART_printf("Logger\n");  
    while(xQueueReceive(shippingQueue, (void *) message, portMAX_DELAY)==pdFALSE)
      vTaskDelay(200);
    UART_printf(message);
  }
}
