#pragma once
#include <stdint.h>
#include <FreeRTOS.h>
#include "portable.h"
#include "portmacro.h"
#include "projdefs.h"
#include "u_task.h"

typedef struct{
  TaskFunction_t TaskCallback;
  char *TaskName;
  configSTACK_DEPTH_TYPE StackSize;
  void *Parameters;
  UBaseType_t Prio;
  TaskHandle_t TaskHandler;
}taskInfo;

//Function to register a task to the watchdog
int TaskDoggyRegister()
//Function to send a notification to the watchdog
//Funciton to remove a task from the watchdog
//
