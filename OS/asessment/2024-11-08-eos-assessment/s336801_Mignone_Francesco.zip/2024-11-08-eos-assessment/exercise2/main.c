#include <stdint.h>
#include <stdio.h>

// It contains only the main function that defines an array of integers v of 10 integers
// Two integer variables min and max
// 
// An inline assembly block that computes the min and max of the array and store the values into min and max
// 
// The result must be printed using the provided  my_printf function


/* This is a function to print strings using UART */
extern void my_printf(const char *s); 

int main(void) {
    int v[10] = {0};
    for (int i=0; i<10; i++) {
         
    }


    return 0;
}


